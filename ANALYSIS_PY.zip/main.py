# main.py
import os
import json
import time
import datetime
import threading
import concurrent.futures
from typing import Dict, Any, List, Tuple
from fastapi import FastAPI, Request, Form, Body, Query
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates

import pandas as pd
import logging
from functools import lru_cache

# --- Modular services (must exist in services/) ---
from services.data_fetch import (
    safe_history,
    save_stocks_list,
    parse_index_csv,
    get_price_history
)

from services.data_fetch import fetch_data
from services.fundamentals import compute_fundamentals
from services.indicators import compute_indicators
# from services.scoring_shortterm import score_short_bull_run
# from services.indicator_signals import compute_signals
# from services.recommendation import build_trade_recommendation
from services.corporate_actions import get_corporate_actions
from services.summaries import build_all_summaries
from services.metrics_ext import compute_extended_metrics, compute_extended_metrics_sync
from services.flowchart_helper import build_flowchart_payload
from services.flowchart_helper import df_hash
from services.signal_engine import compute_all_profiles, compute_profile_score, enrich_hybrid_metrics, generate_trade_plan, score_value_profile, score_growth_profile, score_quality_profile, score_momentum_profile
app = FastAPI()
templates = Jinja2Templates(directory="templates")
logger = logging.getLogger("stock_analyzer")
logging.basicConfig(level=logging.INFO)

DATA_DIR = "data"
os.makedirs(DATA_DIR, exist_ok=True)
NSE_STOCKS_FILE = os.path.join(DATA_DIR, "nse_stocks.json")

# --- Macro Index Ticker Mapping (YF Tickers) ---
MACRO_INDEX_TICKERS = {
    "nifty50": "^NSEI",       # Nifty 50 Index (Primary Benchmark)
    "nifty100": "^NIFTY100.NS",
    "niftynext50": "^NIFTYNEXT50.NS",
    "nifty500": "^NIFTY500.NS",
    "midcap150": "^NIFTYMCAP150.NS",
    "default": "^NSEI" # Default fallback
}



# per-index cache files are in DATA_DIR: e.g. nifty50.json
SCORE_CACHE: Dict[str, Dict[str, Any]] = {}
CACHE_LOCK = threading.Lock()
CACHE_TTL = 60 * 60  # 1 hour


def get_cached(symbol: str):
    with CACHE_LOCK:
        entry = SCORE_CACHE.get(symbol)
        if not entry:
            return None
        if time.time() - entry["ts"] > CACHE_TTL:
            del SCORE_CACHE[symbol]
            return None
        return entry["value"]

def set_cached(symbol: str, value: Dict[str, Any]):
    with CACHE_LOCK:
        SCORE_CACHE[symbol] = {"value": value, "ts": time.time()}


def get_cached_stocks(index_file: str) -> List[Tuple[str, str]]:
    if os.path.exists(index_file):
        try:
            with open(index_file, "r", encoding="utf-8") as f:
                data = json.load(f)
                out: List[Tuple[str, str]] = []
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, dict) and "symbol" in item:
                            out.append((item["symbol"], item.get("name", item["symbol"])))
                        elif isinstance(item, (list, tuple)) and len(item) >= 2:
                            out.append((item[0], item[1]))
                        elif isinstance(item, str):
                            out.append((item, item))
                return out
        except Exception as e:
            logger.exception("Error reading cached stocks: %s", e)
            return []
    return []


INDEX_LIMITS = {
    "nifty50": 50,
    "nifty100": 100,
    "niftynext50": 50,
    "nifty500": 500,
    "midcap150": 150,
    "smallcap100": 100,
    "microcap250": 250
}

# =============================
# 🧩 NEW: CORPORATE ACTION ENDPOINTS
# =============================

# main.py (inside corporate_action_summary)

@app.post("/corporate_action_summary")
async def corporate_action_summary(request: Request):
    """
    Returns the *next upcoming* dividend/bonus/split for each ticker.
    Used only on the index page.
    """
    try:
        body = await request.json()
        tickers = body.get("tickers", [])
        if not tickers:
            return JSONResponse({"error": "No tickers provided"}, status_code=400)

        summary = {}
        # NOTE: Using thread pool here to fetch actions concurrently for speed
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            future_to_ticker = {
                executor.submit(get_corporate_actions, [t], mode="upcoming", lookback_days=365): t
                for t in tickers
            }

            for future in concurrent.futures.as_completed(future_to_ticker):
                t = future_to_ticker[future]
                try:
                    acts = future.result()
                    info = "-"
                    if acts and acts[0].get("actions"):
                        # Get the first (most upcoming) action
                        a = acts[0]["actions"][0]
                        typ = a.get("type", "")
                        amt = a.get("amount")
                        exd = a.get("ex_date")
                        yld = a.get("yield")
                        
                        parts = [typ.replace("Upcoming ", "")] # Trim "Upcoming " for cleaner label
                        
                        # Format Amount/Ratio
                        if amt not in ("", None):
                            if isinstance(amt, (int, float)):
                                parts.append(f"₹{amt}")
                            elif isinstance(amt, str) and amt.startswith('x'): # for splits
                                parts.append(amt)
                            else:
                                parts.append(str(amt))
                                
                        if exd:
                            parts.append(f"Ex: {exd}")
                        if yld not in ("", None):
                            parts.append(f"({yld}%)")

                        info = " ".join(parts)
                    
                    summary[t] = info

                except Exception as e:
                    # print(f"[Error] corporate_action_summary for {t}: {e}")
                    summary[t] = "-"

        # print("✅ Corporate Action Summary ready:", summary)
        return JSONResponse(summary)

    except Exception as e:
        # print("❌ ERROR in /corporate_action_summary:", e)
        return JSONResponse({"error": str(e)}, status_code=500)

@app.get("/corporate_actions")
async def corporate_actions(ticker: str):
    """
    Returns all corporate actions (past + upcoming) for a given ticker.
    Combines your service mode="past" and mode="upcoming" outputs.
    """
    # Past actions (within lookback)
    past = get_corporate_actions([ticker], mode="past", lookback_days=365)
    # Upcoming actions
    upcoming = get_corporate_actions([ticker], mode="upcoming", lookback_days=365)

    flat = []
    # flatten past
    if past:
        for item in past:
            for a in item.get("actions", []):
                # mark as Past (useful in UI)
                a["_when"] = "past"
                flat.append(a)
    # flatten upcoming
    if upcoming:
        for item in upcoming:
            for a in item.get("actions", []):
                a["_when"] = "upcoming"
                flat.append(a)

    # optionally sort by ex_date ascending (put upcoming first if future)
    def _date_key(x):
        try:
            return datetime.date.fromisoformat(x.get("ex_date"))
        except Exception:
            return datetime.date.min
    flat.sort(key=_date_key)

    return JSONResponse(flat)

@app.get("/load_index/{index_name}")
async def load_index(index_name: str):
    """
    Load selected index using CSV in data/<index_name>.csv or cached JSON data/<index_name>.json.
    Returns JSON with list of tickers (symbols).
    """
    name = index_name.lower()
    csv_file = os.path.join(DATA_DIR, f"{name}.csv")
    index_file = os.path.join(DATA_DIR, f"{name}.json")

    # prefer cached JSON
    stocks = get_cached_stocks(index_file)
    if not stocks:
        # try CSV parse
        pairs = parse_index_csv(csv_file)
        if pairs:
            save_stocks_list(pairs, index_file)
            stocks = pairs

    # fallback to small static list if still empty
    if not stocks:
        fallback = [
            ("RELIANCE.NS","RELIANCE"),
            ("TCS.NS","TCS"),
            ("INFY.NS","INFY"),
            ("HDFCBANK.NS","HDFCBANK"),
            ("ICICIBANK.NS","ICICIBANK"),
            ("ITC.NS","ITC"),
            ("LT.NS","L&T"),
            ("SBIN.NS","SBIN"),
            ("HINDUNILVR.NS","HINDUNILVR"),
            ("BHARTIARTL.NS","BHARTIARTL"),
        ]
        save_stocks_list(fallback, index_file)
        stocks = fallback

    limit = INDEX_LIMITS.get(name, 50)
    subset = stocks[:limit]
    tickers = [s for s, _ in subset]
    pairs = {s: n for s, n in subset}

    # persist subset to common NSE_STOCKS_FILE (for index UI)
    try:
        with open(NSE_STOCKS_FILE, "w", encoding="utf-8") as f:
            json.dump([{"symbol": s, "name": n} for s, n in subset], f, indent=2)
    except Exception as e:
        logger.warning("Error writing NSE_STOCKS_FILE: %s", e)

    return {"index": name, "count": len(tickers), "tickers": tickers , "pairs": pairs}

@app.get("/", response_class=HTMLResponse)
async def home(request: Request):
    # load persisted NSE_STOCKS_FILE for initial table (may be empty)
    stocks = []
    if os.path.exists(NSE_STOCKS_FILE):
        try:
            with open(NSE_STOCKS_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
                if isinstance(data, list):
                    for item in data:
                        if isinstance(item, dict) and "symbol" in item:
                            stocks.append((item["symbol"], item.get("name", item["symbol"])))
        except Exception:
            stocks = []
    return templates.TemplateResponse("index.html", {"request": request, "stocks": stocks})

#
# --- ADD THIS NEW "SUPER-ORCHESTRATOR" FUNCTION TO main.py ---
#
#
# --- REPLACE run_full_analysis in main.py ---
#
def run_full_analysis(symbol: str) -> Dict[str, Any]:
    """
    Runs the complete multi-horizon analysis for one stock.
    This is the new core logic.
    """
    
    # 1. Compute Fundamentals (Once)
    fundamentals = compute_fundamentals(symbol)

    # 2. Compute Indicators for ALL horizons
    horizons = ["intraday", "short_term", "long_term", "multibagger"]
    all_indicators = {}
    
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
        future_to_horizon = {
            executor.submit(compute_indicators, symbol, horizon=h): h 
            for h in horizons
        }
        
        for future in concurrent.futures.as_completed(future_to_horizon):
            h = future_to_horizon[future]
            try:
                all_indicators.update(future.result())
            except Exception as e:
                logger.error(f"[{symbol}] Failed to compute indicators for horizon '{h}': {e}")
    
    # 3. Add Price
    try:
        df_st = safe_history(symbol, "3mo", "1d")
        all_indicators["Price"] = {"value": round(df_st["Close"].iloc[-1], 2), "score": 0, "alias": "Price", "desc": "Current Price"}
    except Exception:
        pass 

    # 4. Enrich with Hybrids
    hybrids = enrich_hybrid_metrics(fundamentals, all_indicators)
    fundamentals.update(hybrids)
    
    # --- 5. NEW: Extract Macro Trend (which was already calculated) ---
    macro_trend_status = "N/A"
    macro_close = "N/A"
    try:
        # Our 'long_term' indicator run *already calculated this*.
        # We just need to find it in the combined dictionary.
        nifty_trend_metric = all_indicators.get("nifty_trend_score")
        if nifty_trend_metric:
            macro_trend_status = nifty_trend_metric.get("desc", "N/A")
            
        # Get the Nifty price from a benchmark fetch
        df_bench_long = fetch_data(horizon="long_term") # Uses cache
        if not df_bench_long.empty:
            macro_close = round(df_bench_long["Close"].iloc[-1], 2)
            
    except Exception as e:
        logger.warning(f"[{symbol}] Could not extract macro trend: {e}")

    # 6. Compute ALL Profile Scores
    full_report = compute_all_profiles(
        ticker=symbol,
        fundamentals=fundamentals,
        indicators=all_indicators
    )
    
    # 7. Compute Meta-Category Scores
    full_report["meta_scores"] = {
        "value": score_value_profile(fundamentals),
        "growth": score_growth_profile(fundamentals),
        "quality": score_quality_profile(fundamentals),
        "momentum": score_momentum_profile(fundamentals, all_indicators)
    }

    # 8. Generate Final Trade Plan
    best_profile_name = full_report.get("best_fit", "short_term")
    best_profile_report = full_report.get("profiles", {}).get(best_profile_name, {})
    
    # --- Pass the new macro_trend_status ---
    trade_plan = generate_trade_plan(best_profile_report, all_indicators, macro_trend_status) 
    
    # 9. Return all data
    return {
        "symbol": symbol,
        "fundamentals": fundamentals,
        "indicators": all_indicators,
        "full_report": full_report,
        "trade_recommendation": trade_plan,
        "meta_scores": full_report["meta_scores"],
        "profile_report": best_profile_report,
        
        "macro_trend_status": macro_trend_status,
        "macro_close": macro_close
    }

# --- UPDATED: combine_and_score to accept index_name and apply macro filter ---
# This is the NEW combine_and_score function for main.py
# def combine_and_score(symbol: str, df: pd.DataFrame, index_name: str = "nifty50") -> Dict[str, Any]:
    
#     # --- 1. SET A DEFAULT PROFILE ---
#     # Your app doesn't ask the user for a "profile" (long_term, short_term, etc.)
#     # so we must pick one to run. "short_term" is a great default.
#     PROFILE_TO_RUN = "long_term"  # Change to "short_term" or "momentum" as needed

#     try:
#         # 2. Compute Base Data
#         fundamentals = compute_fundamentals(symbol)
#         benchmark_df = fetch_data()
#         hash_df = df_hash(df)
#         hash_bench = df_hash(benchmark_df)
        
#         # 3. Compute Indicators for the *specific profile*
#         # We pass the horizon to get the correct data
#         indicators = compute_indicators(
#             symbol, 
#             hash_df, 
#             hash_bench, 
#             horizon=PROFILE_TO_RUN
#         )

#         # 4. Enrich with Hybrids (from signal_engine)
#         hybrids = enrich_hybrid_metrics(fundamentals, indicators)
#         if hybrids:
#             fundamentals.update(hybrids) # Add hybrids into the fundamentals dict

#         # 5. Call the NEW Signal Engine
#         # This one function replaces all the old scoring scripts
#         profile_report = compute_profile_score(
#             profile_name=PROFILE_TO_RUN,
#             fundamentals=fundamentals,
#             indicators=indicators
#         )

#         # Generate trade plan based on profile report and indicators
#         trade_plan = generate_trade_plan(profile_report, indicators)

#         # --- 6. Map New Engine's Output to what main.py Expects ---
        
#         # Get scores from our new engine
#         final_score = profile_report.get("final_score", 0)
#         recommendation = profile_report.get("category", "HOLD") # "BUY", "HOLD", "SELL"
        
#         # Get other scores directly from the dictionaries
#         # (Assuming your new HORIZON_PROFILE_MAP doesn't use these, we can default them)
#         technical_score = indicators.get("technical_score", 0)
#         fundamental_score = fundamentals.get("final_score", 0) # Use the fund score we already got
        
#         # NOTE: 'bull_score' and 'confidence' are from your old scripts.
#         # Your new engine doesn't produce them by default.
#         # We can set them to 0 or re-wire them later.
#         # For now, let's use the main score.
#         bull_score = 0 
#         bull_signal = "N/A"
#         confidence = int(final_score * 10) # Simple confidence (e.g., 7.2 -> 72%)

#         # Build the final output dictionary that main.py needs
#         out: Dict[str, Any] = {
#             "symbol": symbol,
#             "technical_score": int(technical_score),
#             "fundamental_score": int(fundamental_score),
#             "bull_score": int(bull_score),
#             "bull_signal": bull_signal,
#             "score": int(final_score * 10), # Composite score (scaled 0-100)
#             "recommendation": recommendation,
#             "confidence": confidence,
#             "reasons": [p['metric'] for p in profile_report.get("applied_penalties", [])], # List of penalties
#             "macro_index_name": index_name.upper(),
#             "macro_trend_status": "N/A", # You can wire this back in later
#             "macro_close": "N/A",
#             "indicators": indicators, 
#             "fundamentals": fundamentals,
#             "trade_recommendation": trade_plan,
#             "profile_report": profile_report
#         }
#         return out

#     except Exception as e:
#         logger.exception("Error in NEW combine_and_score for %s: %s", symbol, e)
#         # Return a default error structure
#         return {
#             "symbol": symbol, "score": 0, "technical_score": 0, "fundamental_score": 0,
#             "confidence": 0, "recommendation": "Error", "bull_score": 0, "bull_signal": "Error",
#             "reasons": [str(e)], "macro_index_name": index_name.upper(), "macro_trend_status": "N/A", "macro_close": "N/A"
#         }
    

# ================== FLOWCHART PAYLOAD ENDPOINT ==================
@app.get("/metrics_ext")
async def metrics_ext_route(ticker: str):
    return await compute_extended_metrics(ticker)

@app.get("/flowchart", response_class=HTMLResponse)
async def show_flowchart(request: Request):
    """
    Serve the Stock Buy-sell Flowcharts visualization page.
    """
    try:
        return templates.TemplateResponse("Stock_Buy-sell_Flowcharts.html", {"request": request})
    except Exception as e:
        import traceback
        traceback.print_exc()
        return HTMLResponse(content=f"<h3>Error rendering flowchart page:</h3><pre>{e}</pre>", status_code=500)

@app.get("/flowchart_payload")
async def flowchart_payload(symbol: str, index: str = Query("NIFTY50")):
    """
    Returns merged payload for flowchart page:
    - quick_score (technical + recommendation)
    - fundamentals (base)
    - extended (advanced metrics)
    - flowchart (normalized mapping: metric -> {value, score})
    """
    try:
        data = await build_flowchart_payload(symbol, index)
        return data
    except Exception as e:
        logger.exception("flowchart_payload failed for %s: %s", symbol, e)
        return {"error": str(e)}


# --- UPDATED: analyze_post to extract index ---
@app.post("/analyze", response_class=HTMLResponse)
async def analyze_post(request: Request, symbol: str = Form(...), index: str = Form("nifty50")):
    return await analyze_common(request, symbol.strip().upper(), index)

# --- UPDATED: analyze_get to extract index ---
@app.get("/analyze", response_class=HTMLResponse)
async def analyze_get(request: Request, symbol: str = Query(...), index: str = Query("nifty50")):
    return await analyze_common(request, symbol.strip().upper(), index)

# --- UPDATED: analyze_common to use combine_and_score and index ---
#
async def analyze_common(request: Request, symbol: str, index: str = "nifty50"):
    
    try:
        # 1. Run the new super-orchestrator
        analysis_data = run_full_analysis(symbol)
        
        # 2. Build Summaries
        summary_payload = {
            **analysis_data,
            **analysis_data["profile_report"],
            "score": analysis_data["profile_report"].get("final_score", 0) * 10,
            "recommendation": analysis_data["profile_report"].get("category", "HOLD"),
            "bull_signal": analysis_data["trade_recommendation"].get("signal", "N/A"),
            # Pass macro data to summaries
            "macro_trend_status": analysis_data["macro_trend_status"],
            "macro_close": analysis_data["macro_close"],
            "macro_index_name": index.upper()
        }
        summaries = build_all_summaries(summary_payload)

        # 3. Create the final context for result.html
        context = {
            "request": request,
            "symbol": symbol,
            "error": None,
            
            "full_report": analysis_data["full_report"], 
            "profile_report": analysis_data["profile_report"], 
            "fundamentals": analysis_data["fundamentals"],
            "indicators": analysis_data["indicators"],
            "meta_scores": analysis_data["meta_scores"],
            "trade_recommendation": analysis_data["trade_recommendation"],
            
            "summaries": summaries,
            
            "final_signal": analysis_data["profile_report"].get("category", "HOLD"),
            "bull_signal": analysis_data["trade_recommendation"].get("signal", "N/A"),
            "total_score": analysis_data["profile_report"].get("final_score", 0) * 10,
            "confidence": int(analysis_data["profile_report"].get("final_score", 0) * 10),

            "macro_index_name": index.upper(),
            "macro_trend_status": analysis_data["macro_trend_status"],
            "macro_close": analysis_data["macro_close"],
            "reasons": [analysis_data["trade_recommendation"]["reason"]] # Use the trade plan reason
        }
        
        return templates.TemplateResponse("result.html", context)

# ... inside analyze_common
    except Exception as e:
        logger.exception(f"Error in analyze_common for {symbol}: {e}")
        # --- THIS IS THE FIX ---
        # We must pass default empty dicts so the error page
        # itself doesn't crash while trying to render.
        return templates.TemplateResponse("result.html", {
            "request": request, 
            "symbol": symbol, 
            "error": str(e),
            "indicators": {}, 
            "trade_recommendation": {},
            "summaries": {},
            "profile_report": {},
            "meta_scores": {}
        })
        # --- END FIX ---

#
# --- REPLACE combine_and_score in main.py ---
#
def combine_and_score(symbol: str, df: pd.DataFrame, index_name: str = "nifty50") -> Dict[str, Any]:
    """
    This function now just runs the full analysis and FLATTENS
    the result for the simple 'index.html' table.
    """
    try:
        # 1. Run the new super-orchestrator
        analysis_data = run_full_analysis(symbol)
        
        # 2. Get the "best" profile to show in the table
        best_profile = analysis_data["profile_report"]
        trade_plan = analysis_data["trade_recommendation"]

        # 3. Flatten the data for the index.html table
        flat_output = {
            "symbol": symbol,
            "score": int(best_profile.get("final_score", 0) * 10),
            "recommendation": best_profile.get("category", "HOLD"),
            "confidence": int(best_profile.get("final_score", 0) * 10),
            "bull_signal": trade_plan.get("signal", "N/A"),
            
            "technical_score": 0,
            "fundamental_score": 0,
            "bull_score": 0,
            
            "macro_index_name": index_name.upper(),
            "macro_trend_status": analysis_data["macro_trend_status"],
            "macro_close": analysis_data["macro_close"]
        }
        return flat_output
        
    except Exception as e:
        logger.exception(f"Error in combine_and_score for {symbol}: {e}")
        return {"symbol": symbol, "score": 0, "recommendation": "Error", "bull_signal": "Error"}

@app.get("/quick_score")
async def quick_score(symbol: str, index: str = Query("nifty50")):
    symbol = symbol.strip().upper()
    cached = get_cached(symbol)
    if cached:
        return {**cached, "cached": True}
        
    df = safe_history(symbol, period="2y")
    if df is None or getattr(df, "empty", True):
        df = get_price_history(symbol)
    if df is None or getattr(df, "empty", True):
        r = {"symbol": symbol, "score": 0, "technical_score": 0, "fundamental_score": 0,
             "confidence": 0, "recommendation": "No Data", "bull_score": 0, "bull_signal": "Weak",
             "macro_index_name": index.upper(), "macro_trend_status": "N/A", "macro_close": "N/A"}
        set_cached(symbol, r)
        return r
    
    # Pass index to combine_and_score
    r = combine_and_score(symbol, df, index_name=index)
    set_cached(symbol, r)
    return r

# --- UPDATED: quick_scores to extract index_name from payload and pass it to worker ---
@app.post("/quick_scores")
async def quick_scores(payload: Dict = Body(...)):
    symbols = payload.get("symbols", []) if isinstance(payload, dict) else []
    symbols = [s.strip().upper() for s in symbols if isinstance(s, str) and s.strip()]
    index_name = payload.get("index_name", "nifty50") # <--- Get index_name from payload
    results: Dict[str, Any] = {}
    to_fetch = []
    
    for s in symbols:
        c = get_cached(s)
        if c:
            results[s] = {**c, "cached": True}
        else:
            to_fetch.append(s)
    if not to_fetch:
        return results

    def worker(sym: str):
        df = safe_history(sym, period="2y")
        if df is None or getattr(df, "empty", True):
            df = get_price_history(sym)
        if df is None or getattr(df, "empty", True):
            r = {"symbol": sym, "score": 0, "technical_score": 0, "fundamental_score": 0,
                 "confidence": 0, "recommendation": "No Data", "bull_score": 0, "bull_signal": "Weak",
                 "macro_index_name": index_name.upper(), "macro_trend_status": "N/A", "macro_close": "N/A"} # <--- Include macro defaults
            set_cached(sym, r)
            return sym, r
        
        # Pass the index_name to combine_and_score
        r = combine_and_score(sym, df, index_name=index_name)
        set_cached(sym, r)
        return sym, r

    max_workers = min(8, max(2, len(to_fetch)//6))
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as exe:
        futures = {exe.submit(worker, s): s for s in to_fetch}
        for fut in concurrent.futures.as_completed(futures):
            sym, out = fut.result()
            results[sym] = out
    return results


@app.post("/clear_cache")
async def clear_cache():
    with CACHE_LOCK:
        SCORE_CACHE.clear()
    return {"cleared": True}

@app.get("/cache_status")
async def cache_status():
    with CACHE_LOCK:
        keys = list(SCORE_CACHE.keys())
    return {"size": len(keys), "symbols": keys[:200]}