# services/data_fetch.py
import asyncio
import functools
import yfinance as yf
from typing import Dict, Optional, Tuple

import numpy as np
import pandas_ta as ta
import pandas as pd
import logging
import os
import json
import time
import math
from functools import lru_cache, partial
from typing import List, Tuple, Any
import yfinance as yf
from typing import Dict, Any, Callable, Optional

from config.constants import TECHNICAL_METRIC_MAP, FUNDAMENTAL_ALIAS_MAP
logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)
ENABLE_INDICATOR_CACHE = False 
# add near top of file (alongside other imports)
import numpy as np
import pandas as pd
from config.constants import HORIZON_FETCH_CONFIG


def _default_indicator_output(note: Optional[str] = None) -> Dict[str, Any]:
    out = {"value": "N/A", "score": 0}
    if note:
        out.setdefault("note", note)
    return out

def _retry(fn, retries=3, backoff=1.5 , name: Optional[str] = None):
    last = None
    for attempt in range(retries):
        try:
            return fn()
        except Exception as e:
            if attempt < retries - 1:
                logger.debug(f"[RETRY] {name or fn.__name__} attempt {attempt+1}/{retries} failed: {e}")
                time.sleep(backoff * (2 ** attempt))
            else:
                logger.warning(f"[FAIL] {name or fn.__name__} after {retries} retries: {e}")
                raise


# ---------------------------
# Helper coercion utilities
# ---------------------------

import functools
from typing import Any, Dict, Callable, Optional
import logging

logger = logging.getLogger(__name__)




def _coerce_value(v: Any) -> Any:
    try:
        import numpy as _np
        import pandas as _pd
    except Exception:
        _np = None
        _pd = None

    if v is None:
        return None
    try:
        if hasattr(v, "item") and callable(v.item):
            return v.item()
    except Exception:
        pass

    if _np is not None and isinstance(v, _np.ndarray):
        if v.ndim == 0:
            return _coerce_value(v.item())
        if v.size <= 20:
            return [_coerce_value(x) for x in v.tolist()]
        return [_coerce_value(x) for x in v.flatten()[:20]]

    if _pd is not None:
        if isinstance(v, _pd.Series) or isinstance(v, _pd.Index):
            lst = v.dropna().tolist() if hasattr(v, "dropna") else v.tolist()
            return [_coerce_value(x) for x in lst[:20]]
        if isinstance(v, _pd.DataFrame):
            if v.shape[0] <= 10 and v.shape[1] <= 6:
                return {c: [_coerce_value(x) for x in v[c].dropna().tolist()] for c in v.columns}
            return v

    if isinstance(v, (int, float, str, bool)):
        return v
    return v


def _normalize_single_metric(d: Dict[str, Any], metric_name: str) -> Dict[str, Any]:
    out = dict(d)
    if "value" in out:
        out["value"] = _coerce_value(out["value"])
    else:
        out["value"] = _coerce_value(out.get("raw"))
    try:
        s = int(round(float(out.get("score", 0))))
    except Exception:
        s = 0
    out["score"] = max(0, min(10, s))
    if not out.get("desc"):
        out["desc"] = f"{metric_name} -> {out.get('value')}"
    else:
        out["desc"] = str(out["desc"])
    return out


def _is_multi_metric_dict(raw: Any) -> bool:
    return isinstance(raw, dict) and all(isinstance(v, dict) for v in raw.values())


def _wrap_calc(arg, name: Optional[str] = None):
    """
    FINAL WORKING WRAPPER
    ---------------------
    ✔ Decorator mode (fundamentals) → single metric dict returned directly
    ✔ Direct-call mode (technical) → multi-metric dict preserved exactly
    ✔ No nesting under alias
    ✔ No top-level contamination
    ✔ Aliases + sources added only inside each metric dict
    """

    # ---------------------------
    # DECORATOR MODE (FUNDAMENTALS)
    # ---------------------------
    if isinstance(arg, str) and name is None:
        metric_key = arg
        alias_name = FUNDAMENTAL_ALIAS_MAP.get(metric_key, metric_key)

        def decorator(fn):
            @functools.wraps(fn)
            def wrapper(*args, **kwargs):
                from services.data_fetch import _retry

                try:
                    raw = _retry(lambda: fn(*args, **kwargs), name=metric_key)
                except Exception as e:
                    return {
                        "value": None,
                        "score": 0,
                        "desc": f"Error: {e}",
                        "alias": alias_name,
                        "source": "core",
                    }

                # SINGLE METRIC ONLY
                if raw is None:
                    return {
                        "value": None,
                        "score": 0,
                        "desc": f"{metric_key} -> None",
                        "alias": alias_name,
                        "source": "core",
                    }

                # raw is dict
                metric = _normalize_single_metric(raw, metric_key)
                metric["alias"] = alias_name
                metric["source"] = "core"
                return metric  # IMPORTANT: return only the dict!
            return wrapper

        return decorator

    # ---------------------------
    # DIRECT-CALL MODE (INDICATORS)
    # ---------------------------
    if callable(arg) and isinstance(name, str):
        fn = arg
        metric_group_alias = TECHNICAL_METRIC_MAP.get(name, name)

        from services.data_fetch import _retry

        try:
            raw = _retry(lambda: fn(), name=name)
        except Exception as e:
            # For direct-call, return multi-metric shape: { key: dict }
            return {
                name: {
                    "value": None,
                    "score": 0,
                    "desc": f"Error: {e}",
                    "alias": metric_group_alias,
                    "source": "technical",
                }
            }

        # raw MUST be a dict of submetrics (your indicator functions guarantee this)
        out = {}
        for sub_key, sub_val in raw.items():
            sub_alias = TECHNICAL_METRIC_MAP.get(sub_key, sub_key)
            metric = _normalize_single_metric(
                sub_val if isinstance(sub_val, dict) else {"value": sub_val},
                sub_key
            )
            metric["alias"] = sub_alias
            metric["source"] = "technical"
            out[sub_key] = metric

        return out  # IMPORTANT: return dict-of-submetrics exactly

    raise TypeError("Invalid usage of _wrap_calc")

# ==============================================================
# 🔤 Helper Utilities
# ==============================================================

@lru_cache(maxsize=1024)
def safe_info(sym: str):
    def _fetch():
        t = yf.Ticker(sym)
        return t.info or {}
    return _retry(_fetch, retries=2, backoff=0.6)

def safe_div(a, b, default=None):
    try:
        if b == 0 or b is None or pd.isna(b):
            return default
        return a / b
    except Exception:
        return default


def _fmt_pct(v: Optional[float]) -> str:
    """Format a float as percentage string or 'N/A'."""
    if v is None:
        return "N/A"
    try:
        if abs(v) < 100:
            return f"{round(v, 2)}%"
        return f"{round(v, 2)}"
    except Exception:
        return str(v)


def _fmt_num(v: Optional[float]) -> str:
    if v is None:
        return "N/A"
    try:
        if abs(v) >= 1e9:
            return f"{v/1e9:.1f}B"
        if abs(v) >= 1e6:
            return f"{v/1e6:.1f}M"
        return f"{round(float(v), 2)}"
    except Exception:
        return str(v)

def _fmt_date(d):
    return d.strftime("%Y-%m-%d") if hasattr(d, "strftime") else str(d)


def _is_missing_entry(e):
    """Return True if a metric entry is missing or invalid."""
    if e is None:
        return True
    if isinstance(e, dict):
        v = e.get("value")
        return v in (None, "", "N/A", "NaN", "nan")
    return e in (None, "", "N/A", "NaN", "nan")

def get_history_for_horizon(symbol: str, horizon: str = "short_term", auto_adjust: bool = True) -> pd.DataFrame:
    """
    Fetch historical OHLCV data using HORIZON_FETCH_CONFIG presets.
    Falls back to default safe_history if horizon is missing.
    """
    cfg = HORIZON_FETCH_CONFIG.get(horizon, HORIZON_FETCH_CONFIG["short_term"])
    period, interval = cfg.get("period", "3mo"), cfg.get("interval", "1d")

    try:
        df = safe_history(symbol, period=period, interval=interval, auto_adjust=auto_adjust)
        if df is None or getattr(df, "empty", True):
            logger.warning(f"[{symbol}] Empty data for horizon={horizon}, trying fallback...")
            df = yf.download(symbol, period=period, interval=interval, auto_adjust=auto_adjust, progress=False)
    except Exception as e:
        logger.warning(f"[{symbol}] Horizon fetch failed ({horizon}): {e}")
        df = pd.DataFrame()

    if df is None or getattr(df, "empty", True):
        logger.warning(f"[{symbol}] No data fetched for horizon={horizon}")
        return pd.DataFrame()
    return df


def safe_history(sym: str, period: str = '2y', auto_adjust: bool = True, **kwargs):
    """
    Safe historical data fetch with retry & optional kwargs.
    Wraps yf.Ticker.history(), supporting dynamic arguments like interval, start, end, etc.
    
    Example:
        df = safe_history("TCS.NS", period="6mo", interval="1d")
        df = safe_history("INFY.NS", start="2023-01-01", end="2024-01-01")
    """
    def _fetch():
        t = yf.Ticker(sym)
        return t.history(period=period, auto_adjust=auto_adjust, **kwargs)

    try:
        df = _retry(_fetch, retries=2, backoff=0.6)
        if df is None or isinstance(df, (list, tuple)) or getattr(df, "empty", True):
            return pd.DataFrame()
        return df
    except Exception:
        return pd.DataFrame()

def safe_get(d: dict, key: str, default=None):
    """Safe getter that returns default for invalid, None or nan-like values."""
    try:
        v = d.get(key, default)
        if v in [None, "None", "NaN", "nan", ""]:
            return default
        return v
    except Exception:
        return default

def normalize_ratio(v):
    """
    Normalize a numeric ratio into a percent-style number.
    Examples:
      0.12 -> 12.0
      12   -> 12.0
      "12%" -> 12.0
      None -> None
    """
    v = safe_float(v)
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return None
    # If value looks like a decimal (e.g. 0.12), convert to percent
    if abs(v) < 2:
        v *= 100
    return v

def safe_json(obj):
    """Recursively convert non-serializable objects to serializable types."""
    if isinstance(obj, (pd.Series, pd.DataFrame)):
        return obj.to_dict()
    elif isinstance(obj, (np.integer, np.floating)):
        return obj.item()
    elif isinstance(obj, np.ndarray):
        return obj.tolist()
    elif isinstance(obj, dict):
        return {k: safe_json(v) for k, v in obj.items()}
    elif isinstance(obj, list):
        return [safe_json(v) for v in obj]
    else:
        return obj

def _num(v) -> Optional[float]:
    """Safe conversion to float — strips ₹ and commas; returns None on failure."""
    if v is None:
        return None
    try:
        if isinstance(v, (int, float)):
            return float(v)
        s = str(v).replace("₹", "").replace(",", "").strip()
        if s in ("", "N/A", "None", "nan"):
            return None
        return float(s)
    except Exception:
        logger.debug("Failed to convert to float: %r", v, exc_info=True)
        return None
    
def _to_float(v: Any, default=None) -> Optional[float]:
    """Safe numeric conversion (mirrors safe_float logic)."""
    try:
        if v is None:
            return None
        if isinstance(v, (int, float)):
            return float(v)
        return float(str(v).replace("%", "").replace("₹", "").strip())
    except Exception:
        return default
        
def safe_float(v, default=None):
    """
    Convert to float with both formatting cleanup and NaN protection.
    Handles currency (₹), percentages (%), commas, and NaN values.
    """
    if v is None:
        return default
    if isinstance(v, float) and np.isnan(v):
        return default
    if isinstance(v, (int, float)):
        return float(v)
    try:
        s = str(v).replace("₹", "").replace("%", "").replace(",", "").strip()
        if s == "":
            return default
        return float(s)
    except Exception:
        return default

async def run_sync_or_async(func, *args, **kwargs):
    """
    Run a function whether it's async or sync.
    For sync functions, runs them in the default threadpool.
    """
    if asyncio.iscoroutinefunction(func):
        # If async, await it directly
        return await func(*args, **kwargs)
    else:
        # If sync, run in threadpool
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, partial(func, *args, **kwargs))

def fetch_data(period: str = None, interval: str = None, auto_adjust: bool = True, horizon: str = None) -> pd.DataFrame:
    """
    Fetch benchmark data (or general data) with either explicit period/interval OR a horizon key.
    - If `horizon` provided, picks period/interval from HORIZON_FETCH_CONFIG.
    - If `period`/`interval` provided explicitly, they take precedence.
    Returns a DataFrame (may be empty).
    """
    # Resolve period/interval: explicit args take precedence, otherwise use horizon config, otherwise default
    if period is None or interval is None:
        if horizon:
            cfg = HORIZON_FETCH_CONFIG.get(horizon, None)
            if cfg:
                period = period or cfg.get("period")
                interval = interval or cfg.get("interval")
        # final fallback defaults
        period = period or "1y"
        interval = interval or "1d"

    # --- Fetch benchmark data (^NSEI) ---
    try:
        benchmark_df = yf.download("^NSEI", period=period, interval=interval, progress=False, auto_adjust=auto_adjust)
        if getattr(benchmark_df, "empty", True):
            logger.warning(f"No NIFTY benchmark data found for period={period}, interval={interval}.")
            benchmark_df = pd.DataFrame()
        else:
            benchmark_df = benchmark_df.sort_index()
    except Exception:
        logger.exception("Error fetching NIFTY benchmark data")
        benchmark_df = pd.DataFrame()

    return benchmark_df

def get_price_history(symbol: str, period: str = "2y", auto_adjust: bool = True) -> pd.DataFrame:
    """
    Fetch price history for a given symbol using yfinance.
    Defaults to auto_adjust=True for cleaner, split/dividend-adjusted prices.
    """
    try:
        t = yf.Ticker(symbol)
        df = t.history(period=period, auto_adjust=auto_adjust)
        if df is None or getattr(df, "empty", True):
            logger.warning(f"No price history for {symbol}")
            return pd.DataFrame()
        try:
            df = df.sort_index()
        except Exception:
            pass
        return df
    except Exception:
        logger.exception("Error fetching price history for %s", symbol)
        return pd.DataFrame()

def save_stocks_list(pairs: List[Tuple[str, str]], index_file: str):
    try:
        with open(index_file, "w", encoding="utf-8") as f:
            # write as list of dicts for readability
            json.dump([{"symbol": s, "name": n} for s, n in pairs], f, indent=2)
    except Exception:
        pass

def parse_index_csv(csv_path: str) -> List[Tuple[str, str]]:
    """
    Parse a CSV file that contains ticker and name columns.
    Accepts common column names: SYMBOL, TICKER, CODE and NAME, COMPANY, SHORTNAME.
    Returns list of (symbol, name).
    """
    pairs: List[Tuple[str, str]] = []
    try:
        if not os.path.exists(csv_path):
            return pairs
        df = pd.read_csv(csv_path, dtype=str).fillna("")
        symbol_col = None
        name_col = None
        for c in df.columns:
            uc = c.strip().upper()
            if uc in ("SYMBOL", "TICKER", "CODE"):
                symbol_col = c
            if uc in ("NAME", "COMPANY", "COMPANYNAME", "SHORTNAME"):
                name_col = c
        if symbol_col is None:
            # try first two columns
            cols = list(df.columns)
            if len(cols) >= 1:
                symbol_col = cols[0]
            if len(cols) >= 2:
                name_col = cols[1]
        for _, row in df.iterrows():
            sym = str(row.get(symbol_col, "")).strip()
            if not sym:
                continue
            if not sym.upper().endswith(".NS"):
                sym = f"{sym}.NS"
            try:
                info = safe_info(sym)
                name = (info.get("shortName") or info.get("longName") or
                        info.get("shortName") or sym.replace(".NS",""))
            except Exception as e:
                logger.warning("Failed to get info for %s: %s", sym, e)
                name = sym.replace(".NS","")
            pairs.append((sym, name))
    except Exception as e:
        logger.exception("Error parsing index CSV")
        return []
    return pairs

def _clamp(v, a, b):
    try:
        return max(a, min(b, v))
    except Exception:
        return a

def _val(indicators: Dict[str, Dict[str, Any]], key: str):
    """Safely extract an indicator's value field (or None)."""
    item = indicators.get(key)
    if not isinstance(item, dict):
        return None
    return item.get("value")
