"""
services/signal_engine_v3.py  —  Final Patched Version

Horizon-based signal engine (v3, enhanced)
------------------------------------------
Integrates fundamentals + indicators to compute multi-horizon scores
(intraday, short_term, long_term, multibagger). Includes hybrid metrics,
penalty capping, and consistent weighted scoring.

Output structure:
{
  "ticker": "<SYMBOL>",
  "profiles": {
      "intraday": { base_score, final_score, category, metric_details, ... },
      ...
  },
  "best_fit": "<profile_name>",
  "aggregate_signal": 7.25,
  "summary": {...}
}

"""

from typing import Dict, Any, Optional, Tuple, List
import math
import operator
import logging
from config.constants import (
    HORIZON_PROFILE_MAP, 
    VALUE_WEIGHTS, 
    GROWTH_WEIGHTS, 
    QUALITY_WEIGHTS, 
    MOMENTUM_WEIGHTS
)

logger = logging.getLogger("signal_engine_v3")
if not logger.handlers:
    h = logging.StreamHandler()
    h.setFormatter(logging.Formatter(
        "[%(asctime)s] [%(levelname)s] signal_engine_v3: %(message)s",
        "%Y-%m-%d %H:%M:%S",
    ))
    logger.addHandler(h)
    logger.setLevel(logging.INFO)


# -----------------------------------------------------------------------------
# Helpers (fallback if not imported from repo)
# -----------------------------------------------------------------------------
def _safe_float(v):
    try:
        if v is None:
            return None
        if isinstance(v, (int, float)):
            return float(v)
        if isinstance(v, str):
            s = v.strip().replace(",", "")
            if s.endswith("%"):
                return float(s[:-1])
            if s.endswith("x"):
                return float(s[:-1])
            if s.lower() in ("n/a", "na", ""):
                return None
            return float(s)
        return float(v)
    except Exception:
        return None


def _coerce_score_field(metric_entry: Dict[str, Any]) -> Optional[float]:
    """Prefer numeric 'score' (0–10). Fallback to 'raw' if already scaled."""
    if not metric_entry:
        return None
    s = metric_entry.get("score")
    if s is not None:
        sf = _safe_float(s)
        return float(sf) if sf is not None else None
    raw = metric_entry.get("raw")
    rv = _safe_float(raw)
    if rv is not None and 0 <= rv <= 10:
        return rv
    return None


_OPS = {
    ">": operator.gt,
    "<": operator.lt,
    "==": operator.eq,
    ">=": operator.ge,
    "<=": operator.le,
    "in": lambda a, b: a in b if b is not None else False,
}


def _rule_matches(raw_val, op: str, tgt) -> bool:
    if raw_val is None:
        return False
    if op == "in":
        try:
            return raw_val in tgt
        except Exception:
            return False
    try:
        if isinstance(raw_val, (int, float)):
            return _OPS[op](float(raw_val), float(tgt))
        return _OPS[op](raw_val, tgt)
    except Exception:
        return False


# -----------------------------------------------------------------------------
# Core retrieval + hybrid enrichment
# -----------------------------------------------------------------------------
def _get_metric_entry(key: str, fundamentals: Dict[str, Any], indicators: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not key:
        return None
    if indicators and key in indicators:
        return indicators.get(key)
    if fundamentals and key in fundamentals:
        return fundamentals.get(key)
    return None


def enrich_hybrid_metrics(fundamentals: dict, indicators: dict) -> dict:
    """
    Adds hybrid metrics derived from both fundamentals and indicators.
    Blends volatility, trend persistence, and fundamental momentum.
    """
    hybrids = {}

    # --- Volatility-Adjusted ROE ---
    roe = _safe_float(fundamentals.get("roe", {}).get("raw"))
    atr_pct = _safe_float(indicators.get("atr_pct", {}).get("value"))
    if roe and atr_pct and atr_pct > 0:
        ratio = roe / atr_pct
        score = 10 if ratio >= 10 else 7 if ratio >= 5 else 3 if ratio >= 2 else 0
        hybrids["volatility_adjusted_roe"] = {
            "raw": ratio,
            "value": round(ratio, 2),
            "score": score,
            "desc": f"ROE/Vol = {ratio:.2f} (ROE {roe:.1f}%, ATR {atr_pct:.2f}%)",
            "alias": "Volatility-Adjusted ROE",
            "source": "hybrid",
        }

    # --- Price vs Intrinsic Value ---
    pe = _safe_float(fundamentals.get("pe_ratio", {}).get("raw"))
    eps_growth = _safe_float(fundamentals.get("eps_growth_5y", {}).get("raw"))
    price = _safe_float(indicators.get("Price", {}).get("value")) or _safe_float(fundamentals.get("current_price"))
    if price and pe and eps_growth and eps_growth > 0:
        intrinsic_value = price * (1 / (pe / eps_growth))
        ratio = price / intrinsic_value
        score = 10 if ratio < 0.8 else 7 if ratio < 1.0 else 3 if ratio < 1.2 else 0
        hybrids["price_vs_intrinsic_value"] = {
            "raw": ratio,
            "value": round(ratio, 2),
            "score": score,
            "desc": f"Price/IV = {ratio:.2f} ({'Undervalued' if ratio < 1 else 'Overvalued'})",
            "alias": "Price vs Intrinsic Value",
            "source": "hybrid",
        }

    # --- FCF Yield vs Volatility ---
    fcf_yield = _safe_float(fundamentals.get("fcf_yield", {}).get("raw"))
    if fcf_yield and atr_pct:
        ratio = fcf_yield / max(atr_pct, 0.1)
        score = 10 if ratio >= 10 else 8 if ratio >= 5 else 5 if ratio >= 2 else 2
        hybrids["fcf_yield_vs_volatility"] = {
            "raw": ratio,
            "value": round(ratio, 2),
            "score": score,
            "desc": f"FCF/Vol = {ratio:.2f} (Yield {fcf_yield:.2f}%, ATR {atr_pct:.2f}%)",
            "alias": "FCF Yield vs Volatility",
            "source": "hybrid",
        }

    # --- Trend Consistency (based on ADX & Supertrend) ---
    adx = _safe_float(indicators.get("adx", {}).get("value") or indicators.get("adx", {}).get("score"))
    supertrend = str(indicators.get("supertrend_signal", {}).get("raw") or "").lower()
    if adx:
        score = 10 if adx >= 25 else 7 if adx >= 20 else 4
        if "bull" in supertrend:
            score += 1
        hybrids["trend_consistency"] = {
            "raw": adx,
            "value": adx,
            "score": min(10, score),
            "desc": f"ADX {adx:.1f} ({'Bullish' if 'bull' in supertrend else 'Neutral'})",
            "alias": "Trend Consistency",
            "source": "hybrid",
        }

    # --- Price vs 200DMA ---
    price = _safe_float(indicators.get("Price", {}).get("value"))
    dma_200 = _safe_float(indicators.get("dma_200", {}).get("value"))
    if price and dma_200:
        ratio = (price / dma_200) - 1
        score = 10 if ratio > 0.1 else 7 if ratio > 0.0 else 3 if ratio > -0.05 else 0
        hybrids["price_vs_200dma"] = {
            "raw": ratio,
            "value": round(ratio * 100, 2),
            "score": score,
            "desc": f"Price vs 200DMA: {ratio*100:.2f}%",
            "alias": "Price vs 200DMA %",
            "source": "hybrid",
        }

    # --- Fundamental Momentum (Quarterly Growth trend) ---
    q_growth = _safe_float(fundamentals.get("quarterly_growth", {}).get("raw"))
    eps_5y = _safe_float(fundamentals.get("eps_growth_5y", {}).get("raw"))
    if q_growth and eps_5y:
        ratio = (q_growth + eps_5y / 5) / 2
        score = 10 if ratio >= 15 else 7 if ratio >= 10 else 4 if ratio >= 5 else 1
        hybrids["fundamental_momentum"] = {
            "raw": ratio,
            "value": round(ratio, 2),
            "score": score,
            "desc": f"Growth Momentum = {ratio:.2f}%",
            "alias": "Fundamental Momentum",
            "source": "hybrid",
        }

    # --- Earnings Consistency Index (ROE + Net Margin stability) ---
    net_margin = _safe_float(fundamentals.get("net_profit_margin", {}).get("raw"))
    if roe and net_margin:
        ratio = (roe + net_margin) / 2
        score = 10 if ratio >= 25 else 7 if ratio >= 15 else 4 if ratio >= 8 else 1
        hybrids["earnings_consistency_index"] = {
            "raw": ratio,
            "value": round(ratio, 2),
            "score": score,
            "desc": f"Consistency Index = {ratio:.2f}",
            "alias": "Earnings Consistency Index",
            "source": "hybrid",
        }

    return hybrids

# 🧩 Optional Future Hybrids (same layer)
# If you adopt this hybrid enrichment pattern, future metrics can include:
# fcf_yield_vs_volatility
# roe_vs_sector_avg
# price_vs_200dma
# earnings_consistency_index
# fundamental_momentum (based on improvement in quarterly_growth)

# -----------------------------------------------------------------------------
# Weighted scoring + penalties
# -----------------------------------------------------------------------------

def _compute_weighted_score(
    metrics_map: Dict[str, Any],
    fundamentals: Dict[str, Any],
    indicators: Dict[str, Any]
) -> Tuple[float, float, Dict[str, float]]:
    
    weighted_sum = 0.0
    weight_sum = 0.0
    details = {}

    critical_metrics = {"vwap_bias", "adx", "supertrend_signal", "price_vs_200dma_pct"}

    # Loop through each metric defined in the profile's weights
    for metric_key, rule in metrics_map.items():
        try:
            # --- Start: Robust "Silent Fail" Block ---
            
            entry = _get_metric_entry(metric_key, fundamentals, indicators)
            
            # 1. Parse the rule (weight & direction)
            weight = 0.0
            direction = "normal"

            if isinstance(rule, dict):
                # New format: {"weight": 0.1, "direction": "invert"}
                weight = rule.get("weight", 0.0)
                direction = rule.get("direction", "normal")
            elif isinstance(rule, (int, float)):
                # Old format: 0.1
                weight = float(rule)
            else:
                # Invalid rule format, log and skip
                logger.warning(f"Skipping metric '{metric_key}': Invalid rule format '{rule}'")
                continue
                
            # If weight is 0, no need to process
            if weight == 0.0:
                continue

            # 2. Check for missing metric data
            if not entry:
                # Penalize for missing critical metric by including its weight
                if metric_key in critical_metrics:
                    weight_sum += weight
                # Silently fail (skip) this non-critical or critical metric
                continue

            # 3. Get the 0-10 score
            score_val = _coerce_score_field(entry)
            
            # 4. Fallback for string-based signals
            if score_val is None:
                raw = entry.get("raw")
                if isinstance(raw, str):
                    rlow = raw.lower()
                    if rlow in ("strong_buy", "buy", "bullish"):
                        score_val = 8.5
                    elif rlow in ("hold", "neutral"):
                        score_val = 5.0
                    elif rlow in ("sell", "bearish", "strong_sell"):
                        score_val = 1.5
            
            # 5. Final check for a valid score
            if score_val is None:
                # Silently fail (skip) if no valid score could be found
                continue

            # 6. Apply direction and add to score
            s = float(score_val)  # Coerce to float
            if direction == "invert":
                s = 10.0 - s  # Invert the score
            
            weighted_sum += s * weight
            weight_sum += weight
            details[metric_key] = s

        except Exception as e:
            # --- CATCH ALL FOR UNEXPECTED ERRORS ---
            # This is the "silent fail" handler. It logs the error
            # but allows the loop to continue to the next metric.
            logger.error(f"Error processing score for metric '{metric_key}': {e}", exc_info=False) # Set exc_info=True for deep debugging
            # Silently continue
            continue
        
    return weighted_sum, weight_sum, details


def _apply_penalties(penalties_map: Dict[str, Dict[str, Any]], fundamentals: Dict[str, Any], indicators: Dict[str, Any]) -> Tuple[float, List[Dict[str, Any]]]:
    """
    Evaluate penalties. Returns (penalty_total, applied_list).
    penalty_total is additive in [0..maybe >1] representing total penalty (later multiply by 10).
    applied_list contains dicts with reason and penalty amount for logging/UI.
    """
    penalty_total = 0.0
    applied = []
    for metric_key, rule in (penalties_map or {}).items():
        entry = _get_metric_entry(metric_key, fundamentals, indicators)
        if not entry:
            continue
        raw = entry.get("raw") or entry.get("value") or entry.get("score")
        raw_num = _safe_float(raw) if not isinstance(raw, (list, dict)) else raw
        op = rule.get("operator")
        tgt = rule.get("value")
        pen = _safe_float(rule.get("penalty")) or 0.0
        matched = _rule_matches(raw_num, op, tgt)
        if matched:
            penalty_total += float(pen)
            applied.append({
                "metric": metric_key,
                "op": op,
                "value": tgt,
                "penalty": float(pen),
                "raw": raw
            })
    # cap total penalty impact (avoid excessive deduction)
    penalty_total = min(penalty_total, 1.0)
    return penalty_total, applied


# -----------------------------------------------------------------------------
# Core Scoring Logic
# -----------------------------------------------------------------------------
def compute_profile_score(profile_name: str, fundamentals: Dict[str, Any], indicators: Dict[str, Any], profile_map: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    profile = (profile_map or HORIZON_PROFILE_MAP).get(profile_name)
    if not profile:
        raise KeyError(f"profile '{profile_name}' not defined in profile_map")

    metrics_map = profile.get("metrics", {})
    penalties_map = profile.get("penalties", {})
    thresholds = profile.get("thresholds", {"buy": 8.0, "hold": 6.0, "sell": 4.0})

    weighted_sum, weight_sum, metric_details = _compute_weighted_score(metrics_map, fundamentals, indicators)
    base_score = round((weighted_sum / weight_sum), 2) if weight_sum > 0 else 0.0

    penalty_total, applied_penalties = _apply_penalties(penalties_map, fundamentals, indicators)

    final_score = base_score - (penalty_total * 10.0)
    final_score = max(0.0, min(10.0, round(final_score, 2)))

    if final_score >= thresholds.get("buy", 8.0):
        category = "BUY"
    elif final_score >= thresholds.get("hold", 6.0):
        category = "HOLD"
    else:
        category = "SELL"

    return {
        "profile": profile_name,
        "base_score": base_score,
        "final_score": final_score,
        "category": category,
        "metric_details": metric_details,
        "penalty_total": round(penalty_total, 4),
        "applied_penalties": applied_penalties,
        "thresholds": thresholds,
        "notes": profile.get("notes", ""),
    }


def compute_all_profiles(ticker: str, fundamentals: Dict[str, Any], indicators: Dict[str, Any], profile_map: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    pm = profile_map or HORIZON_PROFILE_MAP

    # --- Enrich hybrids automatically ---
    hybrids = enrich_hybrid_metrics(fundamentals or {}, indicators or {})
    if hybrids:
        fundamentals.update(hybrids)

    profiles_out = {}
    best_fit, best_score = None, -1.0

    for pname in pm.keys():
        try:
            out = compute_profile_score(pname, fundamentals, indicators, profile_map=pm)
            logger.info(f"{ticker} | {pname.upper():<12} | base={out.get('base_score'):>4} | final={out.get('final_score'):>4} | {out.get('category')}")
        except Exception as e:
            logger.exception("Failed compute_profile_score %s for %s: %s", pname, ticker, e)
            out = {"profile": pname, "error": str(e)}
        profiles_out[pname] = out
        fs = out.get("final_score") or 0.0
        if fs > best_score:
            best_score = fs
            best_fit = pname

    # aggregate signal (mean final_score)
    avg_signal = (
        round(sum(p.get("final_score", 0) for p in profiles_out.values()) / len(profiles_out), 2)
        if profiles_out else 0.0
    )

    summary = {
        "ticker": ticker,
        "best_fit": best_fit,
        "best_score": best_score,
        "aggregate_signal": avg_signal,
        "profiles": profiles_out,
    }
    return summary

#
# --- ADD THIS NEW FUNCTION TO signal_engine.py ---
#

#
# --- ADD THIS NEW FUNCTION to services/signal_engine.py ---
#

def generate_trade_plan(profile_report: Dict[str, Any], 
                        indicators: Dict[str, Any], 
                        macro_trend_status: str = "N/A") -> Dict[str, Any]:
    """
    Generates an actionable trade plan (entry, stop, target)
    based on the profile's rating, indicator setup, and macro trend.
    """
    
    # --- 1. Get the Core "Rating" ---
    final_score = profile_report.get("final_score", 0)
    category = profile_report.get("category", "SELL")

    # --- 2. Get the "Timing" Indicators ---
    price = _safe_float(indicators.get("Price", {}).get("value"))
    adx = _safe_float(indicators.get("adx", {}).get("value"))
    atr = _safe_float(indicators.get("atr_14", {}).get("value")) # Raw ATR value
    
    # New indicators from our latest update
    psar_trend = indicators.get("psar_trend", {}).get("value") # "Bullish" or "Bearish"
    psar_level = _safe_float(indicators.get("psar_level", {}).get("value"))
    squeeze_signal = indicators.get("ttm_squeeze", {}).get("value") # "Squeeze On" or "Squeeze Off"
    
    # Default plan: Do nothing
    plan = {
        "signal": "NO_TRADE",
        "reason": "Rating is 'SELL' or score is too low.",
        "entry": None,
        "stop_loss": None,
        "target": None,
        "rr_ratio": None
    }

    # --- 3. Run the "Timing" Logic ---

    # --- MACRO FILTER (Top Priority) ---
    if "Downtrend" in macro_trend_status or "Bearish" in macro_trend_status:
        plan["reason"] = f"Macro Filter: Market trend is {macro_trend_status}. No long trades."
        return plan

    # --- RATING FILTER ---
    # Only look for trades if the rating is good (e.g., score > 5.5)
    if category not in ("BUY", "HOLD") or final_score < 5.5:
        plan["reason"] = f"HOLD: Rating is too low (Score: {final_score:.1f})."
        return plan

    # --- TIMING FILTERS (ADX / ATR) ---
    if adx is None or adx < 20:
        plan["signal"] = "HOLD_NO_TREND"
        plan["reason"] = f"HOLD: Good rating ({final_score:.1f}), but no clear trend (ADX < 20)."
        return plan

    if atr is None or atr == 0 or psar_level is None or price is None:
        plan["signal"] = "HOLD_NO_RISK"
        plan["reason"] = f"HOLD: Good rating ({final_score:.1f}), but risk (ATR/PSAR/Price) is uncalcuable."
        return plan

    # ---
    # TIMING SIGNAL 1: "High-Confidence Squeeze Buy"
    # ---
    if "Squeeze On" in squeeze_signal and "Bullish" in psar_trend:
        entry = price
        stop_loss = psar_level # Use the tighter PSAR as our stop
        risk = abs(entry - stop_loss)
        if risk == 0: risk = atr * 2 # Fallback
        
        target = entry + (risk * 2.0) # Aim for 2.0 R/R on a breakout
        
        plan.update({
            "signal": "BUY_SQUEEZE",
            "reason": f"High-prob setup: Rating ({final_score:.1f}) + Volatility Squeeze + Bullish PSAR.",
            "entry": round(entry, 2),
            "stop_loss": round(stop_loss, 2),
            "target": round(target, 2),
            "rr_ratio": 2.0
        })
        return plan

    # ---
    # TIMING SIGNAL 2: "Standard Trend-Following Buy"
    # ---
    elif "Bullish" in psar_trend:
        entry = price
        stop_loss = price - (2 * atr) # Use a 2x ATR stop
        
        # Ensure PSAR isn't *too* far
        if stop_loss < psar_level:
            stop_loss = psar_level # Use the tighter (higher) of the two
            
        risk = abs(entry - stop_loss)
        if risk == 0: risk = atr * 2 # Fallback
        
        target = entry + (risk * 1.5) # Aim for 1.5 R/R
        
        plan.update({
            "signal": "BUY_TREND",
            "reason": f"Good rating ({final_score:.1f}) with bullish trend (PSAR).",
            "entry": round(entry, 2),
            "stop_loss": round(stop_loss, 2),
            "target": round(target, 2),
            "rr_ratio": 1.5
        })
        return plan

    # ---
    # TIMING SIGNAL 3: "Hold" (Good Rating, Bad Timing)
    # ---
    elif "Bearish" in psar_trend:
        plan["signal"] = "HOLD_BEARISH_PSAR"
        plan["reason"] = f"HOLD: Good rating ({final_score:.1f}), but short-term PSAR is Bearish. Wait for reversal."
        return plan
        
    # ---
    # TIMING SIGNAL 4: "Hold" (Default)
    # ---
    else:
        plan["signal"] = "HOLD_NEUTRAL"
        plan["reason"] = f"HOLD: Good rating ({final_score:.1f}), but no clear entry signal."
        return plan


# --- Public functions to be called by main.py ---
# -----------------------------------------------------------------------------
# Meta-Category (Archetype) Scoring
# -----------------------------------------------------------------------------

# --- Weight maps for meta-categories ---

def score_value_profile(fundamentals: Dict[str, Any]) -> float:
    """Calculates a 0-10 score for the 'Value' archetype."""
    weighted_sum, weight_sum, _ = _compute_weighted_score(
        VALUE_WEIGHTS, fundamentals, {}
    )
    return round((weighted_sum / weight_sum), 2) if weight_sum > 0 else 0.0

def score_growth_profile(fundamentals: Dict[str, Any]) -> float:
    """Calculates a 0-10 score for the 'Growth' archetype."""
    weighted_sum, weight_sum, _ = _compute_weighted_score(
        GROWTH_WEIGHTS, fundamentals, {}
    )
    return round((weighted_sum / weight_sum), 2) if weight_sum > 0 else 0.0

def score_quality_profile(fundamentals: Dict[str, Any]) -> float:
    """Calculates a 0-10 score for the 'Quality' archetype."""
    weighted_sum, weight_sum, _ = _compute_weighted_score(
        QUALITY_WEIGHTS, fundamentals, {}
    )
    return round((weighted_sum / weight_sum), 2) if weight_sum > 0 else 0.0

def score_momentum_profile(fundamentals: Dict[str, Any], indicators: Dict[str, Any]) -> float:
    """Calculates a 0-10 score for the 'Momentum' archetype."""
    # Note: This one needs both dicts
    weighted_sum, weight_sum, _ = _compute_weighted_score(
        MOMENTUM_WEIGHTS, fundamentals, indicators
    )
    return round((weighted_sum / weight_sum), 2) if weight_sum > 0 else 0.0
# -----------------------------------------------------------------------------
# Local test
# -----------------------------------------------------------------------------
if __name__ == "__main__":
    f = {
        "roe": {"raw": 40.8, "score": 10},
        "roce": {"raw": 49.5, "score": 10},
        "roic": {"raw": 25.0, "score": 10},
        "fcf_yield": {"raw": 1.78, "score": 2},
        "net_profit_margin": {"raw": 33.05, "score": 10},
        "eps_growth_5y": {"raw": 17.61, "score": 10},
        "fcf_growth_3y": {"raw": 11.47, "score": 10},
        "pe_ratio": {"raw": 18.3, "score": 7},
        "pe_vs_sector": {"raw": 0.72, "score": 10},
        "promoter_holding": {"raw": 3.66, "score": 3},
        "market_cap": {"raw": 2.0e11, "score": None},
    }

    ind = {
        "Price": {"value": 815.2},
        "atr_pct": {"value": 4.3},
        "vwap_bias": {"score": 8},
        "price_action": {"score": 7},
        "adx": {"score": 8},
        "supertrend_signal": {"raw": "bullish"},
        "rvol": {"score": 7},
        "macd_histogram": {"score": 6},
        "nifty_trend_score": {"score": 7},
        "bid_ask_spread_pct": {"raw": 0.1},
    }

    out = compute_all_profiles("HINDALCO.NS", f, ind)
    import json
    print(json.dumps(out, indent=2))
